import { useEffect, useState } from 'react';
import { useLanguage } from '../contexts/LanguageContext';
import { supabase } from '../lib/supabase';
import { TrendingUp, TrendingDown, DollarSign, Package, Users, ShoppingCart } from 'lucide-react';

interface Partner {
  id: string;
  name: string;
  name_ar: string;
  share_percentage: number;
}

interface RecentSale {
  id: string;
  sale_number: string;
  total: number;
  sale_date: string;
  customers: { name: string; name_ar: string | null } | null;
}

export function Dashboard() {
  const { t, isRTL, language } = useLanguage();
  const [partners, setPartners] = useState<Partner[]>([]);
  const [recentSales, setRecentSales] = useState<RecentSale[]>([]);
  const [stats, setStats] = useState({
    totalSales: 0,
    totalPurchases: 0,
    netProfit: 0,
    inventoryValue: 0,
  });
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadDashboardData();
  }, []);

  const loadDashboardData = async () => {
    try {
      const [partnersRes, salesRes, purchasesRes, inventoryRes, recentSalesRes] = await Promise.all([
        supabase.from('partners').select('*').eq('is_active', true).order('share_percentage', { ascending: false }),
        supabase.from('sales').select('total').eq('status', 'confirmed'),
        supabase.from('purchases').select('total').in('status', ['confirmed', 'received']),
        supabase.from('inventory').select('quantity, products(purchase_price)'),
        supabase.from('sales').select('id, sale_number, total, sale_date, customers(name, name_ar)').eq('status', 'confirmed').order('sale_date', { ascending: false }).limit(5),
      ]);

      if (partnersRes.data) setPartners(partnersRes.data);
      if (recentSalesRes.data) setRecentSales(recentSalesRes.data as any);

      const totalSales = salesRes.data?.reduce((sum, s) => sum + (s.total || 0), 0) || 0;
      const totalPurchases = purchasesRes.data?.reduce((sum, p) => sum + (p.total || 0), 0) || 0;
      const inventoryValue = inventoryRes.data?.reduce((sum, item: any) => {
        return sum + (item.quantity * (item.products?.purchase_price || 0));
      }, 0) || 0;

      setStats({
        totalSales,
        totalPurchases,
        netProfit: totalSales - totalPurchases,
        inventoryValue,
      });
    } catch (error) {
      console.error('Error loading dashboard:', error);
    } finally {
      setLoading(false);
    }
  };

  const statCards = [
    { title: t('dashboard.totalSales'), value: stats.totalSales, icon: DollarSign, color: 'from-green-500 to-green-600' },
    { title: t('dashboard.totalPurchases'), value: stats.totalPurchases, icon: TrendingDown, color: 'from-red-500 to-red-600' },
    { title: t('dashboard.netProfit'), value: stats.netProfit, icon: TrendingUp, color: 'from-blue-500 to-blue-600' },
    { title: t('dashboard.inventory'), value: stats.inventoryValue, icon: Package, color: 'from-teal-500 to-teal-600' },
  ];

  const formatCurrency = (amount: number) =>
    new Intl.NumberFormat(language === 'ar' ? 'ar-SA' : 'en-US', { style: 'decimal', minimumFractionDigits: 2, maximumFractionDigits: 2 }).format(amount);

  const formatDate = (date: string) =>
    new Date(date).toLocaleDateString(language === 'ar' ? 'ar-SA' : 'en-US', { month: 'short', day: 'numeric' });

  if (loading) {
    return (
      <div className="flex items-center justify-center h-full">
        <div className="text-center">
          <div className="w-16 h-16 border-4 border-teal-600 border-t-transparent rounded-full animate-spin mx-auto"></div>
          <p className="mt-4 text-gray-600">{t('common.loading')}</p>
        </div>
      </div>
    );
  }

  return (
    <div className="p-6 space-y-6">
      <div>
        <h2 className="text-2xl font-bold text-gray-900">{t('nav.dashboard')}</h2>
        <p className="text-gray-500 mt-1">{isRTL ? 'مرحباً بك في نظام بلوف' : 'Welcome to your BLOOV dashboard'}</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {statCards.map((card) => {
          const Icon = card.icon;
          return (
            <div key={card.title} className="bg-white rounded-xl shadow-sm border border-gray-100 overflow-hidden">
              <div className="p-6">
                <div className="flex items-center justify-between mb-4">
                  <div className={`p-3 rounded-lg bg-gradient-to-br ${card.color}`}>
                    <Icon className="w-6 h-6 text-white" />
                  </div>
                </div>
                <h3 className="text-sm font-medium text-gray-500 mb-1">{card.title}</h3>
                <p className="text-2xl font-bold text-gray-900">
                  {formatCurrency(card.value)} <span className="text-sm font-normal text-gray-400">{isRTL ? 'ر.س' : 'SAR'}</span>
                </p>
              </div>
            </div>
          );
        })}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-6">
          <h3 className="text-lg font-bold text-gray-900 mb-4 flex items-center gap-2">
            <Users className="w-5 h-5 text-teal-600" />
            {t('dashboard.partners')}
          </h3>
          {partners.length === 0 ? (
            <p className="text-center py-4 text-gray-400">{isRTL ? 'لا يوجد شركاء' : 'No partners'}</p>
          ) : (
            <div className="space-y-4">
              {partners.map((partner) => (
                <div key={partner.id} className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
                  <div>
                    <h4 className="font-semibold text-gray-900">
                      {language === 'ar' ? partner.name_ar : partner.name}
                    </h4>
                    <p className="text-sm text-gray-500">{partner.share_percentage}% {isRTL ? 'حصة' : 'Share'}</p>
                  </div>
                  <div className="text-right">
                    <p className="text-lg font-bold text-teal-600">
                      {formatCurrency((stats.netProfit * partner.share_percentage) / 100)}
                    </p>
                    <p className="text-xs text-gray-500">{isRTL ? 'الفترة الحالية' : 'Current Period'}</p>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>

        <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-6">
          <h3 className="text-lg font-bold text-gray-900 mb-4 flex items-center gap-2">
            <ShoppingCart className="w-5 h-5 text-teal-600" />
            {t('dashboard.recentSales')}
          </h3>
          {recentSales.length === 0 ? (
            <div className="text-center py-8 text-gray-400">
              <ShoppingCart className="w-12 h-12 mx-auto mb-2 opacity-30" />
              <p>{isRTL ? 'لا توجد مبيعات بعد' : 'No recent sales'}</p>
            </div>
          ) : (
            <div className="space-y-3">
              {recentSales.map((sale) => (
                <div key={sale.id} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                  <div>
                    <p className="font-medium text-gray-900 text-sm">{sale.sale_number}</p>
                    <p className="text-xs text-gray-400">
                      {sale.customers
                        ? (isRTL ? sale.customers.name_ar || sale.customers.name : sale.customers.name)
                        : (isRTL ? 'عميل نقدي' : 'Walk-in')}
                      {' - '}
                      {formatDate(sale.sale_date)}
                    </p>
                  </div>
                  <p className="font-bold text-teal-600">{formatCurrency(sale.total)}</p>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
