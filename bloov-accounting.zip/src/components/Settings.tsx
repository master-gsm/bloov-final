import { useState, useEffect } from 'react';
import { useLanguage } from '../contexts/LanguageContext';
import { useAuth } from '../contexts/AuthContext';
import { supabase } from '../lib/supabase';
import {
  Settings as SettingsIcon, Globe, Building2, Shield, Save, Receipt,
  Truck, Heart, Bell, Package, CreditCard, FileText, QrCode, CheckCircle, Loader2
} from 'lucide-react';

type SettingsMap = Record<string, string>;

const TABS = ['business', 'tax', 'invoice', 'pos', 'inventory', 'loyalty', 'language'] as const;
type Tab = typeof TABS[number];

export function Settings() {
  const { language, setLanguage } = useLanguage();
  const { user } = useAuth();
  const isRTL = language === 'ar';

  const [settings, setSettings] = useState<SettingsMap>({});
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [saved, setSaved] = useState(false);
  const [activeTab, setActiveTab] = useState<Tab>('business');

  useEffect(() => { loadSettings(); }, []);

  const loadSettings = async () => {
    try {
      const { data, error } = await supabase.from('settings').select('key, value');
      if (error) throw error;
      const map: SettingsMap = {};
      data?.forEach(row => { map[row.key] = row.value; });
      setSettings(map);
    } catch (err) {
      console.error('Error loading settings:', err);
    } finally {
      setLoading(false);
    }
  };

  const updateSetting = (key: string, value: string) => {
    setSettings(prev => ({ ...prev, [key]: value }));
    setSaved(false);
  };

  const saveSettings = async () => {
    setSaving(true);
    try {
      const updates = Object.entries(settings).map(([key, value]) => ({
        key,
        value,
        updated_by: user?.id,
        updated_at: new Date().toISOString(),
      }));

      for (const update of updates) {
        await supabase
          .from('settings')
          .upsert(update, { onConflict: 'key' });
      }

      setSaved(true);
      setTimeout(() => setSaved(false), 3000);
    } catch (err) {
      console.error('Error saving settings:', err);
    } finally {
      setSaving(false);
    }
  };

  const tabConfig: Record<Tab, { icon: typeof Building2; label: string; labelAr: string }> = {
    business: { icon: Building2, label: 'Business Info', labelAr: 'معلومات الشركة' },
    tax: { icon: FileText, label: 'Tax & ZATCA', labelAr: 'الضريبة وهيئة الزكاة' },
    invoice: { icon: Receipt, label: 'Invoice', labelAr: 'الفواتير' },
    pos: { icon: CreditCard, label: 'POS & Payments', labelAr: 'نقاط البيع والدفع' },
    inventory: { icon: Package, label: 'Inventory', labelAr: 'المخزون' },
    loyalty: { icon: Heart, label: 'Loyalty', labelAr: 'الولاء' },
    language: { icon: Globe, label: 'Language', labelAr: 'اللغة والعرض' },
  };

  const renderInput = (key: string, label: string, labelAr: string, opts?: { type?: string; placeholder?: string; dir?: string }) => (
    <div key={key}>
      <label className="block text-sm font-medium text-gray-700 mb-1">{isRTL ? labelAr : label}</label>
      <input
        type={opts?.type || 'text'}
        value={settings[key] || ''}
        onChange={(e) => updateSetting(key, e.target.value)}
        className="w-full px-4 py-2.5 border border-gray-300 rounded-lg focus:ring-2 focus:ring-teal-500 focus:border-transparent transition"
        placeholder={opts?.placeholder}
        dir={opts?.dir || (isRTL ? 'rtl' : 'ltr')}
      />
    </div>
  );

  const renderToggle = (key: string, label: string, labelAr: string, description?: string, descriptionAr?: string) => (
    <div key={key} className="flex items-center justify-between p-4 bg-gray-50 rounded-lg hover:bg-gray-100 transition">
      <div>
        <p className="text-sm font-medium text-gray-900">{isRTL ? labelAr : label}</p>
        {(description || descriptionAr) && (
          <p className="text-xs text-gray-500 mt-0.5">{isRTL ? descriptionAr : description}</p>
        )}
      </div>
      <button
        type="button"
        onClick={() => updateSetting(key, settings[key] === 'true' ? 'false' : 'true')}
        className={`relative inline-flex h-6 w-11 items-center rounded-full transition ${settings[key] === 'true' ? 'bg-teal-600' : 'bg-gray-300'}`}
      >
        <span className={`inline-block h-4 w-4 transform rounded-full bg-white transition ${settings[key] === 'true' ? 'translate-x-6' : 'translate-x-1'}`} />
      </button>
    </div>
  );

  const renderSelect = (key: string, label: string, labelAr: string, options: { value: string; label: string; labelAr: string }[]) => (
    <div key={key}>
      <label className="block text-sm font-medium text-gray-700 mb-1">{isRTL ? labelAr : label}</label>
      <select
        value={settings[key] || ''}
        onChange={(e) => updateSetting(key, e.target.value)}
        className="w-full px-4 py-2.5 border border-gray-300 rounded-lg focus:ring-2 focus:ring-teal-500 focus:border-transparent transition"
      >
        {options.map(opt => (
          <option key={opt.value} value={opt.value}>{isRTL ? opt.labelAr : opt.label}</option>
        ))}
      </select>
    </div>
  );

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="w-16 h-16 border-4 border-teal-600 border-t-transparent rounded-full animate-spin" />
      </div>
    );
  }

  return (
    <div className="p-6 space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold text-gray-900">{isRTL ? 'الإعدادات' : 'Settings'}</h2>
          <p className="text-gray-500 mt-1">{isRTL ? 'إعدادات النظام والتحكم بالبرنامج' : 'System settings and program controls'}</p>
        </div>
        <button
          onClick={saveSettings}
          disabled={saving}
          className={`flex items-center gap-2 px-5 py-2.5 rounded-lg font-medium transition ${
            saved
              ? 'bg-green-600 text-white'
              : 'bg-teal-600 text-white hover:bg-teal-700'
          } disabled:opacity-50`}
        >
          {saving ? (
            <><Loader2 className="w-5 h-5 animate-spin" /> {isRTL ? 'جاري الحفظ...' : 'Saving...'}</>
          ) : saved ? (
            <><CheckCircle className="w-5 h-5" /> {isRTL ? 'تم الحفظ' : 'Saved'}</>
          ) : (
            <><Save className="w-5 h-5" /> {isRTL ? 'حفظ الإعدادات' : 'Save Settings'}</>
          )}
        </button>
      </div>

      <div className="flex gap-2 border-b overflow-x-auto pb-px">
        {TABS.map(tab => {
          const config = tabConfig[tab];
          const Icon = config.icon;
          return (
            <button
              key={tab}
              onClick={() => setActiveTab(tab)}
              className={`flex items-center gap-2 px-4 py-2.5 text-sm font-medium border-b-2 transition whitespace-nowrap ${
                activeTab === tab
                  ? 'border-teal-600 text-teal-600'
                  : 'border-transparent text-gray-500 hover:text-gray-700'
              }`}
            >
              <Icon className="w-4 h-4" />
              {isRTL ? config.labelAr : config.label}
            </button>
          );
        })}
      </div>

      <div className="space-y-6">
        {activeTab === 'business' && (
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <div className="bg-white rounded-xl shadow-sm border p-6 space-y-4">
              <h3 className="text-lg font-bold text-gray-900">{isRTL ? 'معلومات الشركة' : 'Company Information'}</h3>
              {renderInput('company_name', 'Company Name', 'اسم الشركة', { dir: 'ltr' })}
              {renderInput('company_name_ar', 'Company Name (Arabic)', 'اسم الشركة (عربي)', { dir: 'rtl' })}
              {renderInput('business_name', 'Business/Brand Name', 'اسم المحل/العلامة التجارية', { dir: 'ltr' })}
              {renderInput('business_name_ar', 'Business Name (Arabic)', 'اسم المحل (عربي)', { dir: 'rtl' })}
              {renderInput('business_type', 'Business Type', 'نوع النشاط', { dir: 'ltr' })}
              {renderInput('business_type_ar', 'Business Type (Arabic)', 'نوع النشاط (عربي)', { dir: 'rtl' })}
              {renderInput('commercial_register', 'Commercial Register', 'السجل التجاري', { dir: 'ltr' })}
            </div>
            <div className="bg-white rounded-xl shadow-sm border p-6 space-y-4">
              <h3 className="text-lg font-bold text-gray-900">{isRTL ? 'معلومات التواصل' : 'Contact Information'}</h3>
              {renderInput('business_phone', 'Phone', 'رقم الهاتف', { dir: 'ltr' })}
              {renderInput('business_address', 'Address', 'العنوان', { dir: 'ltr' })}
              {renderInput('business_address_ar', 'Address (Arabic)', 'العنوان (عربي)', { dir: 'rtl' })}
              {renderInput('business_city', 'City', 'المدينة', { dir: 'ltr' })}
              {renderInput('business_city_ar', 'City (Arabic)', 'المدينة (عربي)', { dir: 'rtl' })}
              {renderSelect('currency', 'Currency', 'العملة', [
                { value: 'SAR', label: 'Saudi Riyal (SAR)', labelAr: 'ريال سعودي (SAR)' },
                { value: 'AED', label: 'UAE Dirham (AED)', labelAr: 'درهم إماراتي (AED)' },
                { value: 'USD', label: 'US Dollar (USD)', labelAr: 'دولار أمريكي (USD)' },
              ])}
            </div>
          </div>
        )}

        {activeTab === 'tax' && (
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <div className="bg-white rounded-xl shadow-sm border p-6 space-y-4">
              <div className="flex items-center gap-3 mb-2">
                <div className="p-2.5 bg-green-100 rounded-lg">
                  <FileText className="w-5 h-5 text-green-600" />
                </div>
                <h3 className="text-lg font-bold text-gray-900">{isRTL ? 'الضريبة' : 'Tax Settings'}</h3>
              </div>
              {renderInput('tax_number', 'Tax Number (VAT)', 'الرقم الضريبي', { dir: 'ltr', placeholder: '300000000000003' })}
              {renderInput('tax_rate', 'Tax Rate (%)', 'نسبة الضريبة (%)', { type: 'number', dir: 'ltr' })}
              {renderToggle('show_tax_on_invoice', 'Show Tax on Invoice', 'عرض الضريبة في الفاتورة')}
              <div className="bg-amber-50 border border-amber-200 rounded-lg p-4">
                <p className="text-sm text-amber-800 font-medium">{isRTL ? 'ملاحظة' : 'Note'}</p>
                <p className="text-xs text-amber-700 mt-1">
                  {isRTL
                    ? 'الرقم الضريبي سيظهر في جميع الفواتير وفي رمز QR الخاص بهيئة الزكاة والضريبة.'
                    : 'The tax number will appear on all invoices and in the ZATCA QR code.'}
                </p>
              </div>
            </div>

            <div className="bg-white rounded-xl shadow-sm border p-6 space-y-4">
              <div className="flex items-center gap-3 mb-2">
                <div className="p-2.5 bg-teal-100 rounded-lg">
                  <QrCode className="w-5 h-5 text-teal-600" />
                </div>
                <h3 className="text-lg font-bold text-gray-900">{isRTL ? 'هيئة الزكاة والضريبة والجمارك' : 'ZATCA Integration'}</h3>
              </div>
              {renderToggle('zatca_enabled', 'Enable ZATCA', 'تفعيل الربط مع الهيئة',
                'Connect to ZATCA for e-invoicing compliance', 'الربط مع هيئة الزكاة والضريبة والجمارك للفوترة الإلكترونية')}
              {renderSelect('zatca_mode', 'ZATCA Mode', 'وضع الربط', [
                { value: 'sandbox', label: 'Sandbox (Testing)', labelAr: 'اختبار (Sandbox)' },
                { value: 'simulation', label: 'Simulation', labelAr: 'محاكاة (Simulation)' },
                { value: 'production', label: 'Production', labelAr: 'إنتاج (Production)' },
              ])}
              {renderInput('zatca_otp', 'ZATCA OTP', 'رمز التحقق OTP', { dir: 'ltr' })}
              {renderSelect('invoice_type', 'Invoice Type', 'نوع الفاتورة', [
                { value: 'simplified', label: 'Simplified Tax Invoice', labelAr: 'فاتورة ضريبية مبسطة' },
                { value: 'standard', label: 'Standard Tax Invoice', labelAr: 'فاتورة ضريبية' },
              ])}
              <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
                <p className="text-sm text-blue-800 font-medium">{isRTL ? 'متطلبات الفوترة الإلكترونية' : 'E-invoicing Requirements'}</p>
                <ul className="text-xs text-blue-700 mt-2 space-y-1 list-disc list-inside">
                  <li>{isRTL ? 'اسم الشركة ورقم السجل التجاري' : 'Company name and commercial register'}</li>
                  <li>{isRTL ? 'الرقم الضريبي (VAT)' : 'Tax number (VAT)'}</li>
                  <li>{isRTL ? 'عنوان الشركة والمدينة' : 'Company address and city'}</li>
                  <li>{isRTL ? 'رمز QR يحتوي على بيانات ZATCA' : 'QR code with ZATCA data'}</li>
                </ul>
              </div>
            </div>
          </div>
        )}

        {activeTab === 'invoice' && (
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <div className="bg-white rounded-xl shadow-sm border p-6 space-y-4">
              <h3 className="text-lg font-bold text-gray-900">{isRTL ? 'إعدادات الفاتورة' : 'Invoice Settings'}</h3>
              {renderInput('invoice_prefix', 'Invoice Prefix', 'بادئة رقم الفاتورة', { dir: 'ltr', placeholder: 'BLV' })}
              {renderToggle('auto_print_invoice', 'Auto Print Invoice', 'طباعة الفاتورة تلقائياً',
                'Automatically print invoice after sale', 'طباعة الفاتورة تلقائياً بعد إتمام البيع')}
              {renderToggle('barcode_enabled', 'Enable Barcode/QR', 'تفعيل الباركود/QR',
                'Show QR code on invoices', 'عرض رمز QR في الفواتير')}
            </div>
            <div className="bg-white rounded-xl shadow-sm border p-6 space-y-4">
              <h3 className="text-lg font-bold text-gray-900">{isRTL ? 'نص الفاتورة' : 'Invoice Text'}</h3>
              {renderInput('invoice_notes', 'Invoice Notes (English)', 'ملاحظات الفاتورة (إنجليزي)', { dir: 'ltr' })}
              {renderInput('invoice_notes_ar', 'Invoice Notes (Arabic)', 'ملاحظات الفاتورة (عربي)', { dir: 'rtl' })}
              {renderInput('receipt_footer', 'Receipt Footer (English)', 'تذييل الإيصال (إنجليزي)', { dir: 'ltr' })}
              {renderInput('receipt_footer_ar', 'Receipt Footer (Arabic)', 'تذييل الإيصال (عربي)', { dir: 'rtl' })}
            </div>
          </div>
        )}

        {activeTab === 'pos' && (
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <div className="bg-white rounded-xl shadow-sm border p-6 space-y-4">
              <h3 className="text-lg font-bold text-gray-900">{isRTL ? 'نقاط البيع' : 'Point of Sale'}</h3>
              {renderSelect('default_payment_method', 'Default Payment Method', 'طريقة الدفع الافتراضية', [
                { value: 'cash', label: 'Cash', labelAr: 'نقدي' },
                { value: 'card', label: 'Card', labelAr: 'بطاقة' },
                { value: 'transfer', label: 'Bank Transfer', labelAr: 'تحويل بنكي' },
              ])}
              {renderToggle('whatsapp_notifications', 'WhatsApp Notifications', 'إشعارات واتساب',
                'Send invoice via WhatsApp', 'إرسال الفاتورة عبر واتساب')}
            </div>
            <div className="bg-white rounded-xl shadow-sm border p-6 space-y-4">
              <h3 className="text-lg font-bold text-gray-900">{isRTL ? 'التوصيل والمناسبات' : 'Delivery & Events'}</h3>
              {renderToggle('delivery_enabled', 'Enable Delivery', 'تفعيل التوصيل')}
              {renderInput('default_delivery_charge', 'Default Delivery Charge', 'رسوم التوصيل الافتراضية', { type: 'number', dir: 'ltr' })}
              {renderToggle('event_orders_enabled', 'Enable Event Orders', 'تفعيل طلبات المناسبات',
                'Allow orders for weddings, birthdays, etc.', 'السماح بطلبات حفلات الزفاف وأعياد الميلاد وغيرها')}
            </div>
          </div>
        )}

        {activeTab === 'inventory' && (
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <div className="bg-white rounded-xl shadow-sm border p-6 space-y-4">
              <h3 className="text-lg font-bold text-gray-900">{isRTL ? 'إعدادات المخزون' : 'Inventory Settings'}</h3>
              {renderToggle('stock_alert_enabled', 'Low Stock Alerts', 'تنبيهات المخزون المنخفض',
                'Notify when stock is below threshold', 'التنبيه عندما ينخفض المخزون عن الحد الأدنى')}
              {renderInput('low_stock_threshold', 'Low Stock Threshold', 'حد المخزون المنخفض', { type: 'number', dir: 'ltr' })}
              {renderToggle('allow_negative_stock', 'Allow Negative Stock', 'السماح بمخزون سالب',
                'Allow sales when stock is zero', 'السماح بالبيع عندما يكون المخزون صفراً')}
            </div>
          </div>
        )}

        {activeTab === 'loyalty' && (
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <div className="bg-white rounded-xl shadow-sm border p-6 space-y-4">
              <h3 className="text-lg font-bold text-gray-900">{isRTL ? 'برنامج الولاء' : 'Loyalty Program'}</h3>
              {renderToggle('loyalty_enabled', 'Enable Loyalty Program', 'تفعيل برنامج الولاء',
                'Earn points on purchases', 'كسب نقاط على المشتريات')}
              {renderInput('loyalty_points_per_sar', 'Points per SAR', 'نقاط لكل ريال', { type: 'number', dir: 'ltr' })}
              {renderInput('loyalty_redemption_rate', 'Points for 1 SAR Discount', 'نقاط مقابل 1 ريال خصم', { type: 'number', dir: 'ltr' })}
            </div>
          </div>
        )}

        {activeTab === 'language' && (
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <div className="bg-white rounded-xl shadow-sm border p-6 space-y-4">
              <h3 className="text-lg font-bold text-gray-900">{isRTL ? 'اللغة والعرض' : 'Language & Display'}</h3>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">{isRTL ? 'اللغة' : 'Language'}</label>
                <select
                  value={language}
                  onChange={(e) => setLanguage(e.target.value as 'en' | 'ar')}
                  className="w-full px-4 py-2.5 border border-gray-300 rounded-lg focus:ring-2 focus:ring-teal-500 focus:border-transparent"
                >
                  <option value="ar">العربية</option>
                  <option value="en">English</option>
                </select>
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">{isRTL ? 'اتجاه الصفحة' : 'Page Direction'}</label>
                <input type="text" value={isRTL ? 'من اليمين إلى اليسار (RTL)' : 'Left to Right (LTR)'} className="w-full px-4 py-2.5 border border-gray-300 rounded-lg bg-gray-50" readOnly />
              </div>
            </div>
            <div className="bg-white rounded-xl shadow-sm border p-6 space-y-4">
              <h3 className="text-lg font-bold text-gray-900">{isRTL ? 'معلومات الحساب' : 'Account Info'}</h3>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">{isRTL ? 'البريد الإلكتروني' : 'Email'}</label>
                <input type="text" value={user?.email || ''} className="w-full px-4 py-2.5 border border-gray-300 rounded-lg bg-gray-50" readOnly dir="ltr" />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">{isRTL ? 'الإصدار' : 'Version'}</label>
                <input type="text" value="1.0.0 - BLOOV Accounting System" className="w-full px-4 py-2.5 border border-gray-300 rounded-lg bg-gray-50" readOnly />
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
