import { useEffect, useState } from 'react';
import { useLanguage } from '../contexts/LanguageContext';
import { useAuth } from '../contexts/AuthContext';
import { supabase } from '../lib/supabase';
import { Users, Plus, TrendingUp, ArrowRightLeft, DollarSign, Calendar, X, ShieldAlert, Trash2 } from 'lucide-react';

interface Partner {
  id: string;
  name: string;
  name_ar: string;
  share_percentage: number;
  email: string | null;
  phone: string | null;
}

interface Contribution {
  id: string;
  partner_id: string;
  amount: number;
  description: string;
  description_ar: string | null;
  contribution_date: string;
  created_at: string;
}

export function Partners() {
  const { t, language } = useLanguage();
  const { user } = useAuth();
  const isRTL = language === 'ar';
  const [partners, setPartners] = useState<Partner[]>([]);
  const [contributions, setContributions] = useState<Contribution[]>([]);
  const [loading, setLoading] = useState(true);
  const [isAdmin, setIsAdmin] = useState(false);
  const [showAddForm, setShowAddForm] = useState(false);
  const [selectedPartner, setSelectedPartner] = useState('');
  const [amount, setAmount] = useState('');
  const [description, setDescription] = useState('');
  const [descriptionAr, setDescriptionAr] = useState('');
  const [contribDate, setContribDate] = useState(new Date().toISOString().split('T')[0]);
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState('');
  const [deleteConfirm, setDeleteConfirm] = useState<string | null>(null);

  useEffect(() => {
    checkAdminAndLoad();
  }, [user]);

  const checkAdminAndLoad = async () => {
    if (!user) return;
    try {
      const { data: role } = await supabase.rpc('get_my_role');

      const admin = role === 'admin';
      setIsAdmin(admin);

      if (!admin) {
        setLoading(false);
        return;
      }

      await loadData();
    } catch (err) {
      console.error('Error:', err);
      setLoading(false);
    }
  };

  const loadData = async () => {
    try {
      const [partnersRes, contribRes] = await Promise.all([
        supabase.from('partners').select('*').eq('is_active', true).order('share_percentage', { ascending: false }),
        supabase.from('partner_contributions').select('*').order('contribution_date', { ascending: false }),
      ]);

      if (partnersRes.data) setPartners(partnersRes.data);
      if (contribRes.data) setContributions(contribRes.data);
    } catch (err) {
      console.error('Error loading data:', err);
    } finally {
      setLoading(false);
    }
  };

  const handleAddContribution = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedPartner || !amount) return;
    setError('');
    setSubmitting(true);

    try {
      const { error: insertError } = await supabase.from('partner_contributions').insert({
        partner_id: selectedPartner,
        amount: parseFloat(amount),
        description: descriptionAr || 'دفعة رسوم تأسيس',
        description_ar: descriptionAr || null,
        contribution_date: contribDate,
        created_by: user?.id,
      });

      if (insertError) throw insertError;

      setShowAddForm(false);
      setSelectedPartner('');
      setAmount('');
      setDescription('');
      setDescriptionAr('');
      setContribDate(new Date().toISOString().split('T')[0]);
      await loadData();
    } catch (err: any) {
      setError(err.message || 'Error adding contribution');
    } finally {
      setSubmitting(false);
    }
  };

  const handleDelete = async (id: string) => {
    try {
      const { error } = await supabase.from('partner_contributions').delete().eq('id', id);
      if (error) throw error;
      setDeleteConfirm(null);
      await loadData();
    } catch (err) {
      console.error('Error deleting:', err);
    }
  };

  const getPartnerTotal = (partnerId: string) =>
    contributions.filter((c) => c.partner_id === partnerId).reduce((sum, c) => sum + Number(c.amount), 0);

  const getPartnerContributions = (partnerId: string) =>
    contributions.filter((c) => c.partner_id === partnerId);

  const formatCurrency = (amount: number) =>
    new Intl.NumberFormat('en-US', { style: 'decimal', minimumFractionDigits: 2 }).format(amount);

  const formatDate = (date: string) =>
    new Date(date).toLocaleDateString(isRTL ? 'ar-SA' : 'en-US', { year: 'numeric', month: 'short', day: 'numeric' });

  if (loading) {
    return (
      <div className="flex items-center justify-center h-full">
        <div className="text-center">
          <div className="w-16 h-16 border-4 border-teal-600 border-t-transparent rounded-full animate-spin mx-auto" />
          <p className="mt-4 text-gray-600">{t('common.loading')}</p>
        </div>
      </div>
    );
  }

  if (!isAdmin) {
    return (
      <div className="flex items-center justify-center h-full">
        <div className="text-center max-w-md">
          <div className="bg-red-50 w-20 h-20 rounded-full flex items-center justify-center mx-auto mb-4">
            <ShieldAlert className="w-10 h-10 text-red-500" />
          </div>
          <h2 className="text-2xl font-bold text-gray-900 mb-2">
            {isRTL ? 'غير مصرح' : 'Access Restricted'}
          </h2>
          <p className="text-gray-500">
            {isRTL ? 'هذا القسم متاح فقط للمدير' : 'This section is only available for administrators'}
          </p>
        </div>
      </div>
    );
  }

  const sami = partners.find((p) => p.name === 'Sami');
  const anas = partners.find((p) => p.name === 'Anas');

  const samiTotal = sami ? getPartnerTotal(sami.id) : 0;
  const anasTotal = anas ? getPartnerTotal(anas.id) : 0;
  const totalSetupFees = samiTotal + anasTotal;
  const difference = samiTotal - anasTotal;

  const samiExpected = totalSetupFees * (sami ? Number(sami.share_percentage) / 100 : 0.6);
  const anasExpected = totalSetupFees * (anas ? Number(anas.share_percentage) / 100 : 0.4);

  const samiOwes = samiExpected - samiTotal;
  const anasOwes = anasExpected - anasTotal;

  return (
    <div className="p-6 space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold text-gray-900">{t('nav.partners')}</h2>
          <p className="text-gray-500 mt-1">
            {isRTL ? 'تتبع رسوم التأسيس والأرصدة بين الشركاء' : 'Track setup fees and balances between partners'}
          </p>
        </div>
        <button
          onClick={() => setShowAddForm(true)}
          className="flex items-center gap-2 bg-teal-600 text-white px-4 py-2.5 rounded-lg hover:bg-teal-700 transition font-medium"
        >
          <Plus className="w-5 h-5" />
          {isRTL ? 'إضافة دفعة' : 'Add Payment'}
        </button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-6">
          <div className="flex items-center gap-3 mb-2">
            <div className="bg-teal-50 p-2.5 rounded-lg">
              <DollarSign className="w-5 h-5 text-teal-600" />
            </div>
            <p className="text-sm text-gray-500">{isRTL ? 'إجمالي رسوم التأسيس' : 'Total Setup Fees'}</p>
          </div>
          <p className="text-2xl font-bold text-gray-900">{formatCurrency(totalSetupFees)} <span className="text-sm font-normal text-gray-500">{isRTL ? 'ر.س' : 'SAR'}</span></p>
        </div>

        <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-6">
          <div className="flex items-center gap-3 mb-2">
            <div className="bg-blue-50 p-2.5 rounded-lg">
              <TrendingUp className="w-5 h-5 text-blue-600" />
            </div>
            <p className="text-sm text-gray-500">{isRTL ? `دفعات ${sami ? (isRTL ? sami.name_ar : sami.name) : 'سامي'}` : `${sami ? sami.name : 'Sami'}'s Payments`}</p>
          </div>
          <p className="text-2xl font-bold text-gray-900">{formatCurrency(samiTotal)} <span className="text-sm font-normal text-gray-500">{isRTL ? 'ر.س' : 'SAR'}</span></p>
          <p className="text-xs text-gray-400 mt-1">{sami ? `${sami.share_percentage}%` : '60%'} {isRTL ? 'حصة' : 'share'}</p>
        </div>

        <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-6">
          <div className="flex items-center gap-3 mb-2">
            <div className="bg-amber-50 p-2.5 rounded-lg">
              <TrendingUp className="w-5 h-5 text-amber-600" />
            </div>
            <p className="text-sm text-gray-500">{isRTL ? `دفعات ${anas ? (isRTL ? anas.name_ar : anas.name) : 'أنس'}` : `${anas ? anas.name : 'Anas'}'s Payments`}</p>
          </div>
          <p className="text-2xl font-bold text-gray-900">{formatCurrency(anasTotal)} <span className="text-sm font-normal text-gray-500">{isRTL ? 'ر.س' : 'SAR'}</span></p>
          <p className="text-xs text-gray-400 mt-1">{anas ? `${anas.share_percentage}%` : '40%'} {isRTL ? 'حصة' : 'share'}</p>
        </div>
      </div>

      <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-6">
        <div className="flex items-center gap-3 mb-4">
          <ArrowRightLeft className="w-5 h-5 text-gray-600" />
          <h3 className="text-lg font-bold text-gray-900">{isRTL ? 'التسوية بين الشركاء' : 'Settlement Between Partners'}</h3>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div className="border border-gray-200 rounded-xl p-5">
            <div className="flex items-center gap-3 mb-4">
              <div className="bg-teal-100 w-10 h-10 rounded-full flex items-center justify-center">
                <Users className="w-5 h-5 text-teal-700" />
              </div>
              <div>
                <p className="font-bold text-gray-900">{sami ? (isRTL ? sami.name_ar : sami.name) : (isRTL ? 'سامي' : 'Sami')}</p>
                <p className="text-xs text-gray-500">{sami ? `${sami.share_percentage}%` : '60%'} {isRTL ? 'حصة' : 'share'}</p>
              </div>
            </div>
            <div className="space-y-2 text-sm">
              <div className="flex justify-between">
                <span className="text-gray-500">{isRTL ? 'المبلغ المدفوع' : 'Amount Paid'}</span>
                <span className="font-bold">{formatCurrency(samiTotal)} {isRTL ? 'ر.س' : 'SAR'}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-500">{isRTL ? 'المبلغ المطلوب حسب الحصة' : 'Required (by share)'}</span>
                <span className="font-medium">{formatCurrency(samiExpected)} {isRTL ? 'ر.س' : 'SAR'}</span>
              </div>
              <div className="border-t pt-2 flex justify-between">
                <span className="text-gray-700 font-medium">{isRTL ? 'الرصيد' : 'Balance'}</span>
                <span className={`font-bold ${samiOwes > 0 ? 'text-red-600' : samiOwes < 0 ? 'text-green-600' : 'text-gray-900'}`}>
                  {samiOwes > 0
                    ? `${isRTL ? 'يحتاج يدفع' : 'Owes'} ${formatCurrency(samiOwes)}`
                    : samiOwes < 0
                    ? `${isRTL ? 'له مبلغ' : 'Owed'} ${formatCurrency(Math.abs(samiOwes))}`
                    : (isRTL ? 'متساوي' : 'Settled')}
                </span>
              </div>
            </div>
          </div>

          <div className="border border-gray-200 rounded-xl p-5">
            <div className="flex items-center gap-3 mb-4">
              <div className="bg-amber-100 w-10 h-10 rounded-full flex items-center justify-center">
                <Users className="w-5 h-5 text-amber-700" />
              </div>
              <div>
                <p className="font-bold text-gray-900">{anas ? (isRTL ? anas.name_ar : anas.name) : (isRTL ? 'أنس' : 'Anas')}</p>
                <p className="text-xs text-gray-500">{anas ? `${anas.share_percentage}%` : '40%'} {isRTL ? 'حصة' : 'share'}</p>
              </div>
            </div>
            <div className="space-y-2 text-sm">
              <div className="flex justify-between">
                <span className="text-gray-500">{isRTL ? 'المبلغ المدفوع' : 'Amount Paid'}</span>
                <span className="font-bold">{formatCurrency(anasTotal)} {isRTL ? 'ر.س' : 'SAR'}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-500">{isRTL ? 'المبلغ المطلوب حسب الحصة' : 'Required (by share)'}</span>
                <span className="font-medium">{formatCurrency(anasExpected)} {isRTL ? 'ر.س' : 'SAR'}</span>
              </div>
              <div className="border-t pt-2 flex justify-between">
                <span className="text-gray-700 font-medium">{isRTL ? 'الرصيد' : 'Balance'}</span>
                <span className={`font-bold ${anasOwes > 0 ? 'text-red-600' : anasOwes < 0 ? 'text-green-600' : 'text-gray-900'}`}>
                  {anasOwes > 0
                    ? `${isRTL ? 'يحتاج يدفع' : 'Owes'} ${formatCurrency(anasOwes)}`
                    : anasOwes < 0
                    ? `${isRTL ? 'له مبلغ' : 'Owed'} ${formatCurrency(Math.abs(anasOwes))}`
                    : (isRTL ? 'متساوي' : 'Settled')}
                </span>
              </div>
            </div>
          </div>
        </div>

        {difference !== 0 && (
          <div className="mt-4 p-4 bg-gray-50 rounded-xl border border-gray-200">
            <p className="text-center font-medium text-gray-700">
              {difference > 0
                ? (isRTL
                  ? `${sami ? sami.name_ar : 'سامي'} دفع أكثر من ${anas ? anas.name_ar : 'أنس'} بمبلغ ${formatCurrency(Math.abs(difference))} ر.س`
                  : `${sami ? sami.name : 'Sami'} paid ${formatCurrency(Math.abs(difference))} SAR more than ${anas ? anas.name : 'Anas'}`)
                : (isRTL
                  ? `${anas ? anas.name_ar : 'أنس'} دفع أكثر من ${sami ? sami.name_ar : 'سامي'} بمبلغ ${formatCurrency(Math.abs(difference))} ر.س`
                  : `${anas ? anas.name : 'Anas'} paid ${formatCurrency(Math.abs(difference))} SAR more than ${sami ? sami.name : 'Sami'}`)}
            </p>
          </div>
        )}
      </div>

      {partners.map((partner) => {
        const partnerContribs = getPartnerContributions(partner.id);
        if (partnerContribs.length === 0) return null;

        return (
          <div key={partner.id} className="bg-white rounded-xl shadow-sm border border-gray-100">
            <div className="px-6 py-4 border-b border-gray-100 flex items-center gap-3">
              <Calendar className="w-5 h-5 text-gray-400" />
              <h3 className="font-bold text-gray-900">
                {isRTL ? `سجل دفعات ${partner.name_ar}` : `${partner.name}'s Payment History`}
              </h3>
            </div>
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead>
                  <tr className="border-b border-gray-100">
                    <th className="text-left py-3 px-6 font-semibold text-gray-600 text-sm">{isRTL ? 'التاريخ' : 'Date'}</th>
                    <th className="text-left py-3 px-6 font-semibold text-gray-600 text-sm">{isRTL ? 'الوصف' : 'Description'}</th>
                    <th className="text-left py-3 px-6 font-semibold text-gray-600 text-sm">{isRTL ? 'المبلغ' : 'Amount'}</th>
                    <th className="text-left py-3 px-6 font-semibold text-gray-600 text-sm w-16"></th>
                  </tr>
                </thead>
                <tbody>
                  {partnerContribs.map((contrib) => (
                    <tr key={contrib.id} className="border-b border-gray-50 hover:bg-gray-50/50 transition">
                      <td className="py-3 px-6 text-sm text-gray-600">{formatDate(contrib.contribution_date)}</td>
                      <td className="py-3 px-6 text-sm">{isRTL ? (contrib.description_ar || contrib.description) : contrib.description}</td>
                      <td className="py-3 px-6 text-sm font-bold text-gray-900">{formatCurrency(Number(contrib.amount))} {isRTL ? 'ر.س' : 'SAR'}</td>
                      <td className="py-3 px-6">
                        <button
                          onClick={() => setDeleteConfirm(contrib.id)}
                          className="p-1.5 text-red-500 hover:bg-red-50 rounded-lg transition"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        );
      })}

      {contributions.length === 0 && (
        <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-12 text-center">
          <DollarSign className="w-16 h-16 mx-auto mb-3 text-gray-300" />
          <p className="text-lg font-medium text-gray-500">{isRTL ? 'لا توجد دفعات مسجلة' : 'No payments recorded yet'}</p>
          <p className="text-sm text-gray-400 mt-1">{isRTL ? 'سجل أول دفعة رسوم تأسيس' : 'Record the first setup fee payment'}</p>
        </div>
      )}

      {showAddForm && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-xl shadow-xl max-w-md w-full">
            <div className="border-b px-6 py-4 flex items-center justify-between">
              <h3 className="text-xl font-bold text-gray-900">
                {isRTL ? 'إضافة دفعة رسوم تأسيس' : 'Add Setup Fee Payment'}
              </h3>
              <button onClick={() => setShowAddForm(false)} className="p-2 hover:bg-gray-100 rounded-lg">
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleAddContribution} className="p-6 space-y-4">
              {error && (
                <div className="bg-red-50 border border-red-200 text-red-600 px-4 py-3 rounded-lg text-sm">{error}</div>
              )}

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">{isRTL ? 'الشريك' : 'Partner'}</label>
                <select
                  required
                  value={selectedPartner}
                  onChange={(e) => setSelectedPartner(e.target.value)}
                  className="w-full px-4 py-2.5 border border-gray-300 rounded-lg focus:ring-2 focus:ring-teal-500 focus:border-transparent"
                >
                  <option value="">{isRTL ? 'اختر الشريك' : 'Select Partner'}</option>
                  {partners.map((p) => (
                    <option key={p.id} value={p.id}>{isRTL ? p.name_ar : p.name}</option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">{isRTL ? 'المبلغ (ر.س)' : 'Amount (SAR)'}</label>
                <input
                  type="number"
                  required
                  step="0.01"
                  min="0.01"
                  value={amount}
                  onChange={(e) => setAmount(e.target.value)}
                  className="w-full px-4 py-2.5 border border-gray-300 rounded-lg focus:ring-2 focus:ring-teal-500 focus:border-transparent"
                  placeholder="0.00"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">{isRTL ? 'التاريخ' : 'Date'}</label>
                <input
                  type="date"
                  required
                  value={contribDate}
                  onChange={(e) => setContribDate(e.target.value)}
                  className="w-full px-4 py-2.5 border border-gray-300 rounded-lg focus:ring-2 focus:ring-teal-500 focus:border-transparent"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">{isRTL ? 'الوصف' : 'Description'}</label>
                <input
                  type="text"
                  value={descriptionAr}
                  onChange={(e) => setDescriptionAr(e.target.value)}
                  className="w-full px-4 py-2.5 border border-gray-300 rounded-lg focus:ring-2 focus:ring-teal-500 focus:border-transparent"
                  placeholder={isRTL ? 'رسوم تأسيس' : 'Setup fee'}
                  dir="rtl"
                />
              </div>

              <div className="flex gap-3 pt-2">
                <button
                  type="submit"
                  disabled={submitting}
                  className="flex-1 bg-teal-600 text-white py-2.5 rounded-lg hover:bg-teal-700 transition disabled:opacity-50 font-medium"
                >
                  {submitting ? (isRTL ? 'جاري الحفظ...' : 'Saving...') : (isRTL ? 'حفظ' : 'Save')}
                </button>
                <button
                  type="button"
                  onClick={() => setShowAddForm(false)}
                  className="flex-1 bg-gray-100 text-gray-700 py-2.5 rounded-lg hover:bg-gray-200 transition font-medium"
                >
                  {isRTL ? 'إلغاء' : 'Cancel'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {deleteConfirm && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-xl shadow-xl max-w-sm w-full p-6 text-center">
            <Trash2 className="w-12 h-12 text-red-500 mx-auto mb-3" />
            <h3 className="text-lg font-bold text-gray-900 mb-2">
              {isRTL ? 'تأكيد الحذف' : 'Confirm Delete'}
            </h3>
            <p className="text-gray-500 mb-6 text-sm">
              {isRTL ? 'هل أنت متأكد من حذف هذه الدفعة؟' : 'Are you sure you want to delete this payment?'}
            </p>
            <div className="flex gap-3">
              <button
                onClick={() => handleDelete(deleteConfirm)}
                className="flex-1 bg-red-600 text-white py-2.5 rounded-lg hover:bg-red-700 transition font-medium"
              >
                {isRTL ? 'حذف' : 'Delete'}
              </button>
              <button
                onClick={() => setDeleteConfirm(null)}
                className="flex-1 bg-gray-100 text-gray-700 py-2.5 rounded-lg hover:bg-gray-200 transition font-medium"
              >
                {isRTL ? 'إلغاء' : 'Cancel'}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
